pythonanywhere does not support our apischeduler threding tasks so we use it Schedule Tasks facility 
where scripts are executed at scheduled time.