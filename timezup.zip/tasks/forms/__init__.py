from .task_form import TaskForm
from .login_form import LoginForm
from .register_form import RegisterForm
from .password_change_request_form import PasswordChangeRequestForm
from .password_change_confirm_form import PasswordChangeConfirmForm